package main.src.models;

public class Cliente { public int id; public String nome; }
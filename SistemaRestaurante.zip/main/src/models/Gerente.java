package main.src.models;

public class Gerente { public int id; public String nome; public void fecharComanda(Cliente c) {} }
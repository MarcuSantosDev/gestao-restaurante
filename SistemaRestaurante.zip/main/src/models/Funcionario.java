package main.src.models;

public class Funcionario { public int id; public String nome; }
package main.src.service;

import main.src.models.Cliente;

public class PedidoService { public void adicionarPedidoAoCliente(Cliente cliente, String desc, int qtd, double preco) {} public void exibirComanda(Cliente cliente) {} }
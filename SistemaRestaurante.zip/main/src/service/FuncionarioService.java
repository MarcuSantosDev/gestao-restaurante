package main.src.service;

public class FuncionarioService { public void contratarFuncionario(String nome, String cargo) {} public void listarFuncionarios() {} }
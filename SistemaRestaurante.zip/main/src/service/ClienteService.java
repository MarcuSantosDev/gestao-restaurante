package main.src.service;

import main.src.models.Cliente;

public class ClienteService { public void cadastrarCliente(String nome) {} public void listarClientes() {} public java.util.Optional<Cliente> buscarPorId(int id) { return java.util.Optional.empty(); }}
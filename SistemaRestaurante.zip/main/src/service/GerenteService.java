package main.src.service;

import main.src.models.Gerente;

public class GerenteService { public Gerente cadastrarGerente(String nome) { return new Gerente(); } public java.util.Optional<Gerente> buscarPorId(int id) { return java.util.Optional.empty(); }}